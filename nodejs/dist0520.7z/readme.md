## 使用说明
    index.js 、index.config.js 为接口文件，index.config.js.md5 、 index.js.md5为对应的MD5文件。解压并修改index.config.js文件，相应位置按要求填入自己的阿里token，夸克cookie，live直播源地址可设置多地址，部署小雅的填入小雅VOD地址，内置或按网络接口教程部署在云端即可使用，推荐使用 index.js.md5 以便提高加载速度。


## Support using private Gitee or GitHub repositories as remote config.
    * github://<your personal access token>@github.com/<owner>/<repo>/<ref>/<file path>
    * gitee://<your access token>@gitee.com/<owner>/<repo>/<ref>/<file path>
    * github://ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx@github.com/omii/catvod/main/omii/index.js.md5
    * gitee://xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx@gitee.com/omii/catvod/master/omii/index.js.md5
    * https://omii%40qq.com:88888888@dav.jianguoyun.com/dav/omii/index.js.md5


## 远端配置：
    * github://ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx@github.com/omiitop/CatVod/main/omii/index.js.md5
    * gitee://xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx@gitee.com/omiitop/CatVod/main/omii/index.js.md5


## 本地配置：
    * assets://omii/index.js.md5

## 远程配置教程：
    * https://omii.top/1296.html

## iOS签名教程
    * https://omii.top/826.html
    * https://omii.top/1498.html 推荐

## Nodejs构建打包教程
    * https://omii.top/2019.html


##  更新日志
    *新增小米盘搜，橘子盘搜。
    *修复开心源。
    *支持webdav 和 alist阿里开放接口。

        以上由omii.top提供
